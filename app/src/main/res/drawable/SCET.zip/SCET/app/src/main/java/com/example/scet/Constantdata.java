package com.example.scet;

public class Constantdata {
    public static final String SP_LOGIN="User";
    public static final String SP_USERNAME="username";
    public static final String SP_FULLNAME="fullname";
    public static final String SP_EMAIL="email";
    public static final String SP_PHONE="phone";
    public  static  final String  KEY_PIC="key_pic";

}
