package com.example.scet;

public class Map<T, T1> {
}
